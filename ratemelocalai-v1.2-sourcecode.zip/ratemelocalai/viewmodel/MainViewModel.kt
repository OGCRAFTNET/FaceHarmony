package com.example.ratemelocalai.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ratemelocalai.data.repository.DataRepository
import com.example.ratemelocalai.domain.model.FaceAnalysisResult
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = DataRepository(application)

    private val _lastResult = MutableStateFlow<FaceAnalysisResult?>(null)
    val lastResult: StateFlow<FaceAnalysisResult?> = _lastResult.asStateFlow()

    private val _history = MutableStateFlow<List<FaceAnalysisResult>>(emptyList())
    val history: StateFlow<List<FaceAnalysisResult>> = _history.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _voiceGuideEnabled = MutableStateFlow(false)
    val voiceGuideEnabled: StateFlow<Boolean> = _voiceGuideEnabled.asStateFlow()

    private val _goldenRatioEnabled = MutableStateFlow(false)
    val goldenRatioEnabled: StateFlow<Boolean> = _goldenRatioEnabled.asStateFlow()

    private val _onboardingCompleted = MutableStateFlow(false)
    val onboardingCompleted: StateFlow<Boolean> = _onboardingCompleted.asStateFlow()

    init {
        viewModelScope.launch {
            repository.lastResultFlow.collect { _lastResult.value = it }
        }
        viewModelScope.launch {
            repository.historyFlow.collect { _history.value = it }
        }
        viewModelScope.launch {
            repository.onboardingCompletedFlow.collect { _onboardingCompleted.value = it }
        }
    }

    data class AnalysisOptions(
        val bodyFat: Boolean = true,
        val faceShape: Boolean = true,
        val eyebrows: Boolean = true,
        val eyeShape: Boolean = true,
        val skin: Boolean = true,
        val hair: Boolean = true,
        val mathAnalysis: Boolean = true,
        val attractiveness: Boolean = true,
        val improvementTips: Boolean = true
    )

    private val _analysisOptions = MutableStateFlow(AnalysisOptions())
    val analysisOptions: StateFlow<AnalysisOptions> = _analysisOptions.asStateFlow()

    fun updateAnalysisOptions(options: AnalysisOptions) {
        _analysisOptions.value = options
    }

    fun setAnalysisResult(result: FaceAnalysisResult) {
        _lastResult.value = result
        _history.update { current -> (listOf(result) + current).take(10) }
        _isAnalyzing.value = false
        
        viewModelScope.launch {
            repository.saveLastResult(result)
            repository.saveHistory(_history.value)
        }
    }

    fun startAnalysis() {
        _isAnalyzing.value = true
    }

    fun toggleVoiceGuide() {
        _voiceGuideEnabled.value = !_voiceGuideEnabled.value
    }

    fun toggleGoldenRatio() {
        _goldenRatioEnabled.value = !_goldenRatioEnabled.value
    }

    fun resetOnboarding() {
        _onboardingCompleted.value = false
        viewModelScope.launch {
            repository.setOnboardingCompleted(false)
        }
    }
    
    fun completeOnboarding() {
        _onboardingCompleted.value = true
        viewModelScope.launch {
            repository.setOnboardingCompleted(true)
        }
    }

    fun clearUserData() {
        _lastResult.value = null
        _history.value = emptyList()
        viewModelScope.launch {
            repository.clearAllData()
        }
    }
}
