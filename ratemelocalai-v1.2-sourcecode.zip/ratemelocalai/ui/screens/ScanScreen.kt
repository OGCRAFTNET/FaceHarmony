package com.example.ratemelocalai.ui.screens

import android.Manifest
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ratemelocalai.camera.FaceMeshAnalyzer
import com.example.ratemelocalai.camera.MediaPipeFaceAnalyzer
import com.example.ratemelocalai.domain.model.FaceAnalysisResult
import com.example.ratemelocalai.ui.components.FaceMeshOverlay
import com.example.ratemelocalai.ui.components.GlassCard
import com.example.ratemelocalai.ui.components.LiquidBackground
import com.example.ratemelocalai.ui.components.LiquidButton
import com.example.ratemelocalai.viewmodel.MainViewModel
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.Executors
import kotlin.math.abs

enum class ScanStep(val instruction: String, val yawTarget: Float) {
    FRONT("Front Profile", 0f),
    SLIGHT_LEFT("Tilt Left", 12f),
    LEFT("Full Left", 28f),
    SLIGHT_RIGHT("Tilt Right", -12f),
    RIGHT("Full Right", -28f),
    DONE("Analyzing...", 0f)
}

@Composable
fun ScanScreen(
    viewModel: MainViewModel,
    onResult: (FaceAnalysisResult) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    
    val analysisOptions by viewModel.analysisOptions.collectAsState()

    var hasCameraPermission by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> hasCameraPermission = granted }

    LaunchedEffect(Unit) { launcher.launch(Manifest.permission.CAMERA) }

    var currentStep by remember { mutableStateOf(ScanStep.FRONT) }
    var currentResult by remember { mutableStateOf<FaceLandmarkerResult?>(null) }
    var meshWidth by remember { mutableIntStateOf(0) }
    var meshHeight by remember { mutableIntStateOf(0) }
    var currentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    
    val capturedResults = remember { mutableStateMapOf<String, FaceLandmarkerResult?>() }
    val capturedBitmaps = remember { mutableStateMapOf<String, Bitmap>() }
    var isAnalyzing by remember { mutableStateOf(false) }
    var lastCapturedStep by remember { mutableStateOf<ScanStep?>(null) }
    
    var currentYaw by remember { mutableFloatStateOf(0f) }
    var showMenu by remember { mutableStateOf(true) }

    val cameraAlpha by animateFloatAsState(
        targetValue = if (showMenu) 0f else 1f,
        animationSpec = tween(1500, easing = EaseInOutQuart)
    )
    val blurRadius by animateDpAsState(
        targetValue = if (showMenu) 60.dp else 0.dp,
        animationSpec = tween(1200, easing = EaseInOutQuart)
    )

    LaunchedEffect(currentResult) {
        val pose = FaceMeshAnalyzer.detectPose(currentResult)
        if (pose != null) {
            currentYaw = pose.yaw
        }

        if (!isAnalyzing) return@LaunchedEffect
        
        if (pose != null) {
            val threshold = 7f 
            val diff = abs(pose.yaw - currentStep.yawTarget)
            
            if (diff < threshold && lastCapturedStep != currentStep) {
                capturedResults[currentStep.name] = currentResult
                currentBitmap?.let { capturedBitmaps[currentStep.name] = it }
                lastCapturedStep = currentStep
                
                when (currentStep) {
                    ScanStep.FRONT -> currentStep = ScanStep.SLIGHT_LEFT
                    ScanStep.SLIGHT_LEFT -> currentStep = ScanStep.LEFT
                    ScanStep.LEFT -> currentStep = ScanStep.SLIGHT_RIGHT
                    ScanStep.SLIGHT_RIGHT -> currentStep = ScanStep.RIGHT
                    ScanStep.RIGHT -> {
                        currentStep = ScanStep.DONE
                        isAnalyzing = false
                        val result = FaceMeshAnalyzer.calculateFinalScore(capturedResults.toMap(), capturedBitmaps.toMap())
                        onResult(result)
                    }
                    else -> {}
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        LiquidBackground(showBlackBase = false)
        
        if (hasCameraPermission) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = androidx.camera.core.Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val imageAnalysis = androidx.camera.core.ImageAnalysis.Builder()
                            .setBackpressureStrategy(androidx.camera.core.ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .setOutputImageFormat(androidx.camera.core.ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                            .build()
                            .also {
                                it.setAnalyzer(cameraExecutor, MediaPipeFaceAnalyzer(ctx) { result, w, h, bitmap ->
                                    currentResult = result
                                    meshWidth = w
                                    meshHeight = h
                                    currentBitmap = bitmap
                                })
                            }
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, imageAnalysis)
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }, 
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = cameraAlpha }
                    .blur(blurRadius)
            )
            
            if (!showMenu) {
                FaceMeshOverlay(currentResult, meshWidth, meshHeight, isFrontCamera = true, showHeatmap = false)
                // Biometric HUD
                BiometricHUD(currentYaw, currentStep.yawTarget)
            }
        }

        Box(modifier = Modifier.fillMaxSize().zIndex(10f)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 24.dp, end = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Text("SCAN PROTOCOL", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Box(modifier = Modifier.size(44.dp))
            }

            AnimatedVisibility(
                visible = showMenu,
                enter = fadeIn(tween(600)) + scaleIn(tween(800), initialScale = 0.92f),
                exit = fadeOut(tween(600)) + scaleOut(tween(800), targetScale = 0.92f),
                modifier = Modifier.align(Alignment.Center)
            ) {
                LiquidMenu(
                    options = analysisOptions,
                    onOptionChange = { viewModel.updateAnalysisOptions(it) },
                    onStart = { 
                        showMenu = false
                        isAnalyzing = true
                    }
                )
            }

            if (isAnalyzing && !showMenu) {
                Box(modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 60.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(currentStep.instruction, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        val progress by animateFloatAsState(targetValue = (currentStep.ordinal.toFloat() / (ScanStep.entries.size - 1)))
                        Box(modifier = Modifier.width(160.dp).height(6.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f))) {
                            Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(progress).background(Color(0xFF0A84FF)))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BiometricHUD(yaw: Float, target: Float) {
    val indicatorPos by animateFloatAsState(targetValue = (yaw / 45f).coerceIn(-1f, 1f))
    val targetPos = (target / 45f).coerceIn(-1f, 1f)
    
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Canvas(modifier = Modifier.padding(top = 140.dp).size(200.dp, 40.dp)) {
            val center = size.width / 2
            // Track
            drawLine(Color.White.copy(alpha = 0.1f), start = androidx.compose.ui.geometry.Offset(0f, 20.dp.toPx()), end = androidx.compose.ui.geometry.Offset(size.width, 20.dp.toPx()), strokeWidth = 2.dp.toPx())
            // Target
            drawCircle(Color.White.copy(alpha = 0.3f), radius = 6.dp.toPx(), center = androidx.compose.ui.geometry.Offset(center + targetPos * center, 20.dp.toPx()))
            // Current
            drawCircle(if (abs(yaw - target) < 7f) Color(0xFF32D74B) else Color.White, radius = 4.dp.toPx(), center = androidx.compose.ui.geometry.Offset(center + indicatorPos * center, 20.dp.toPx()))
        }
    }
}

@Composable
fun LiquidMenu(options: MainViewModel.AnalysisOptions, onOptionChange: (MainViewModel.AnalysisOptions) -> Unit, onStart: () -> Unit) {
    GlassCard(modifier = Modifier.padding(24.dp), cornerRadius = 48) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(64.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.05f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoGraph, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text("Biometric Scan", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(32.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LiquidToggle("Anatomy (Phi)", options.mathAnalysis) { onOptionChange(options.copy(mathAnalysis = it)) }
                LiquidToggle("Full Symmetry", options.faceShape) { onOptionChange(options.copy(faceShape = it)) }
                LiquidToggle("Ocular Metrics", options.eyeShape) { onOptionChange(options.copy(eyeShape = it)) }
                LiquidToggle("Jawline Definition", options.bodyFat) { onOptionChange(options.copy(bodyFat = it)) }
            }
            Spacer(modifier = Modifier.height(40.dp))
            LiquidButton(text = "Start Protocol", onClick = onStart, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun LiquidToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onCheckedChange(!checked) }.padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp)
        Switch(checked = checked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF0A84FF)))
    }
}
