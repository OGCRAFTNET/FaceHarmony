package com.example.ratemelocalai.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ratemelocalai.R
import com.example.ratemelocalai.domain.model.FaceAnalysisResult
import com.example.ratemelocalai.ui.components.GlassCard
import com.example.ratemelocalai.ui.components.LiquidBackground
import com.example.ratemelocalai.ui.components.LiquidButton
import com.example.ratemelocalai.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onStartScan: () -> Unit,
    onDatingAnalyzer: () -> Unit,
    onPhotoSelector: () -> Unit,
    onImprovementTips: () -> Unit,
    onSettings: () -> Unit
) {
    val lastResult by viewModel.lastResult.collectAsState()
    val history by viewModel.history.collectAsState()
    val scrollState = rememberScrollState()
    
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")
    val orbScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ), label = "orbScale"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        LiquidBackground()
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // --- HEADER ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 64.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = null,
                        modifier = Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "FaceHarmony",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = (-0.5).sp
                    )
                }
                
                IconButton(
                    onClick = onSettings,
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // --- MAIN SCORE ORB ---
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .graphicsLayer {
                        scaleX = orbScale
                        scaleY = orbScale
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .blur(60.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFF0A84FF).copy(alpha = 0.15f), Color.Transparent)
                            )
                        )
                )
                
                Box(
                    modifier = Modifier
                        .fillMaxSize(0.85f)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.02f))
                            )
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val displayScore = lastResult?.overallScore?.let { (it / 10.0).toString().take(3) } ?: "--"
                        Text(
                            text = displayScore,
                            color = Color.White,
                            fontSize = 64.sp,
                            fontWeight = FontWeight.ExtraLight,
                            letterSpacing = (-4).sp
                        )
                        Text(
                            text = "GLOBAL HARMONY",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // --- FEATURE GRID ---
            HomeSectionHeader("AI Protocol Selection")
            Spacer(modifier = Modifier.height(16.dp))
            
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                FeatureCard(
                    title = "Deep Face Scan",
                    desc = "Biometric 5-step analysis",
                    icon = Icons.Default.Face,
                    color = Color(0xFF0A84FF),
                    onClick = onStartScan
                )

                FeatureCard(
                    title = "Glow-Up Tips",
                    desc = "AI Personalized Routine",
                    icon = Icons.Default.Lightbulb,
                    color = Color(0xFF34C759),
                    onClick = onImprovementTips
                )
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    FeatureCard(
                        modifier = Modifier.weight(1f),
                        title = "Dating Analyzer",
                        desc = "Optimize profile",
                        icon = Icons.Default.Favorite,
                        color = Color(0xFFFF2D55),
                        isAlpha = true,
                        onClick = onDatingAnalyzer
                    )
                    FeatureCard(
                        modifier = Modifier.weight(1f),
                        title = "Best Photo",
                        desc = "AI selection",
                        icon = Icons.Default.AutoAwesome,
                        color = Color(0xFFAF52DE),
                        isAlpha = true,
                        onClick = onPhotoSelector
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // --- PROGRESS CHART ---
            if (history.size >= 2) {
                HomeSectionHeader("Glow-Up Progress")
                Spacer(modifier = Modifier.height(16.dp))
                GlassCard(modifier = Modifier.fillMaxWidth().height(140.dp), cornerRadius = 32) {
                    ProgressChart(history)
                }
                Spacer(modifier = Modifier.height(32.dp))
            }

            // --- QUICK STATS ---
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                GlassCard(modifier = Modifier.weight(1f), cornerRadius = 32) {
                    Column {
                        Text("Estimated Age", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(lastResult?.estimatedAge?.let { "~$it" } ?: "--", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    }
                }
                GlassCard(modifier = Modifier.weight(1f), cornerRadius = 32) {
                    Column {
                        Text("AI Protocol", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("v1.2 High-Res", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(64.dp))
        }
    }
}

@Composable
fun FeatureCard(
    modifier: Modifier = Modifier,
    title: String,
    desc: String,
    icon: ImageVector,
    color: Color,
    isAlpha: Boolean = false,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier.clickable { onClick() },
        cornerRadius = 32,
        padding = 20.dp
    ) {
        Column {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
                }
                
                if (isAlpha) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("ALPHA", color = Color.White.copy(alpha = 0.4f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
        }
    }
}

@Composable
fun ProgressChart(history: List<FaceAnalysisResult>) {
    val scores = history.reversed().map { it.overallScore.toFloat() }
    
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val padding = 20.dp.toPx()
        
        val maxScore = 100f
        val minScore = 30f
        val range = maxScore - minScore
        
        val path = Path()
        val stepX = (width - 2 * padding) / (scores.size - 1).coerceAtLeast(1)
        
        scores.forEachIndexed { i, score ->
            val x = padding + i * stepX
            val y = height - padding - ((score - minScore) / range) * (height - 2 * padding)
            
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            
            drawCircle(
                color = Color(0xFF0A84FF),
                radius = 4.dp.toPx(),
                center = androidx.compose.ui.geometry.Offset(x, y)
            )
        }
        
        drawPath(
            path = path,
            color = Color.White.copy(alpha = 0.4f),
            style = Stroke(width = 2.dp.toPx())
        )
    }
}

@Composable
private fun HomeSectionHeader(title: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(start = 4.dp)) {
        Icon(Icons.AutoMirrored.Filled.TrendingUp, null, tint = Color(0xFF0A84FF), modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title.uppercase(),
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
    }
}
