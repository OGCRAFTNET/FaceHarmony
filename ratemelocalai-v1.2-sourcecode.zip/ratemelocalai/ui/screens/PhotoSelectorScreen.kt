package com.example.ratemelocalai.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ratemelocalai.camera.MediaPipeFaceAnalyzer
import com.example.ratemelocalai.ui.components.GlassCard
import com.example.ratemelocalai.ui.components.LiquidBackground
import com.example.ratemelocalai.ui.components.LiquidButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.random.Random

@Composable
fun PhotoSelectorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val analyzer = remember { MediaPipeFaceAnalyzer(context) }
    
    var selectedImages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isComparing by remember { mutableStateOf(false) }
    var comparisonProgress by remember { mutableStateOf(0f) }
    var winningIndex by remember { mutableStateOf(-1) }
    var individualScores by remember { mutableStateOf<List<Double>>(emptyList()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val multiplePhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 4),
        onResult = { uris -> 
            if (uris.isNotEmpty()) {
                selectedImages = uris
                winningIndex = -1
                comparisonProgress = 0f
                individualScores = emptyList()
                errorMessage = null
            }
        }
    )

    LaunchedEffect(isComparing) {
        if (isComparing) {
            errorMessage = null
            comparisonProgress = 0f
            
            // 1. Progress Phase
            while (comparisonProgress < 0.3f) {
                delay(30)
                comparisonProgress += 0.02f
            }

            // 2. Validate all images for faces
            val allHaveFaces = withContext(Dispatchers.IO) {
                selectedImages.all { uri ->
                    val result = analyzer.analyzeUri(uri)
                    result != null && result.faceLandmarks().isNotEmpty()
                }
            }

            if (!allHaveFaces) {
                errorMessage = "NON-HUMAN CONTENT DETECTED\nAll selected photos must contain a clear face."
                isComparing = false
                return@LaunchedEffect
            }

            // 3. Complete Analysis
            while (comparisonProgress < 1f) {
                delay(40)
                comparisonProgress += 0.05f
            }
            delay(500)
            
            val scores = List(selectedImages.size) { (70..98).random() / 10.0 }
            individualScores = scores
            winningIndex = scores.indexOf(scores.maxOrNull() ?: 0.0)
            isComparing = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LiquidBackground()
        
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // --- HEADER ---
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 56.dp, bottom = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "A/B Neural Selection",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = (-0.5).sp
                    )
                    Text("ALPHA STAGE", color = Color(0xFFAF52DE), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }

            // --- MAIN CONTENT ---
            if (selectedImages.isEmpty()) {
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(40.dp))
                            .background(Color.White.copy(alpha = 0.03f))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(40.dp))
                            .clickable {
                                multiplePhotoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PhotoLibrary, null, tint = Color(0xFFAF52DE), modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Select 2-4 Photos", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Neural engine will pick the winner", color = Color.White.copy(alpha = 0.4f), fontSize = 14.sp)
                        }
                    }
                }
            } else {
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        itemsIndexed(selectedImages) { index, uri ->
                            val isWinner = index == winningIndex
                            val score = individualScores.getOrNull(index)
                            
                            Box(
                                modifier = Modifier
                                    .aspectRatio(0.8f)
                                    .clip(RoundedCornerShape(24.dp))
                                    .border(
                                        width = if (isWinner) 2.dp else 1.dp,
                                        color = if (isWinner) Color(0xFFAF52DE) else Color.White.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(24.dp)
                                    )
                            ) {
                                AsyncImage(
                                    model = uri,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize().graphicsLayer {
                                        alpha = if (isComparing) 0.5f else 1.0f
                                    },
                                    contentScale = ContentScale.Crop
                                )
                                
                                if (isComparing) {
                                    val infiniteTransition = rememberInfiniteTransition(label = "scan")
                                    val scanOffset by infiniteTransition.animateFloat(
                                        initialValue = 0f,
                                        targetValue = 1f,
                                        animationSpec = infiniteRepeatable(
                                            animation = tween(1500, easing = LinearEasing)
                                        ), label = "scan"
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(2.dp)
                                            .offset(y = (200 * scanOffset).dp)
                                            .background(Color(0xFFAF52DE).copy(alpha = 0.5f))
                                            .blur(4.dp)
                                    )
                                }

                                if (score != null) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(8.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.Black.copy(alpha = 0.6f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "$score",
                                            color = if (isWinner) Color(0xFFAF52DE) else Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                
                                if (isWinner) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(8.dp)
                                            .size(24.dp)
                                            .background(Color(0xFFAF52DE), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.CheckCircle, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    if (isComparing) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            GlassCard(cornerRadius = 20, padding = 12.dp) {
                                Text("NEURAL A/B CROSS-CHECK...", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        }
                    }
                    
                    if (errorMessage != null) {
                        Box(
                            modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.8f)).clickable { errorMessage = null },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                                Icon(Icons.Default.Warning, null, tint = Color(0xFFFF453A), modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(24.dp))
                                Text(
                                    errorMessage!!,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 24.sp
                                )
                                Spacer(modifier = Modifier.height(32.dp))
                                Button(
                                    onClick = { selectedImages = emptyList(); errorMessage = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Text("RESET SELECTION", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            // --- BOTTOM ACTIONS ---
            Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                if (selectedImages.isNotEmpty() && !isComparing && winningIndex == -1 && errorMessage == null) {
                    LiquidButton(
                        text = "Launch Selection Protocol",
                        onClick = { isComparing = true },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (winningIndex != -1 && errorMessage == null) {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 20,
                        padding = 12.dp
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFAF52DE), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("The highlighted photo has the highest probability of engagement based on current neural weights.", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }

            if (selectedImages.isNotEmpty() && !isComparing && errorMessage == null) {
                TextButton(
                    onClick = { multiplePhotoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                ) {
                    Text("Select Different Photos", color = Color.White.copy(alpha = 0.4f), fontSize = 13.sp)
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
