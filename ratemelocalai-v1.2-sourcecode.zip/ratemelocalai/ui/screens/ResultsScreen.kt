package com.example.ratemelocalai.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ratemelocalai.domain.model.FaceAnalysisResult
import com.example.ratemelocalai.ui.components.GlassCard
import com.example.ratemelocalai.ui.components.LiquidBackground
import com.example.ratemelocalai.ui.components.LiquidButton
import com.example.ratemelocalai.viewmodel.MainViewModel
import kotlin.math.pow
import kotlin.math.roundToInt

@Composable
fun ResultsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onSettings: () -> Unit
) {
    val result by viewModel.lastResult.collectAsState()
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    Box(modifier = Modifier.fillMaxSize()) {
        LiquidBackground()
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp)
        ) {
            // --- HEADER ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 64.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.1f))
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                
                Text(
                    "ANALYSIS REPORT",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )

                IconButton(
                    onClick = onSettings,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.1f))
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                }
            }

            result?.let { res ->
                // --- SCORE ORB CARD ---
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularRatingDisplay(score = res.overallScore)
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Text(
                            text = when {
                                res.overallScore > 90 -> "ELITE AESTHETICS"
                                res.overallScore > 80 -> "HIGH APPEAL"
                                else -> "HARMONIOUS VIBE"
                            },
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        
                        Text(
                            text = "NEURAL HARMONY INDEX",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // --- MAIN BIOMETRIC PREVIEW ---
                SectionHeader("Neural Analysis Base")
                Spacer(modifier = Modifier.height(16.dp))
                GlassCard(
                    modifier = Modifier.fillMaxWidth().height(320.dp),
                    cornerRadius = 48,
                    padding = 0.dp
                ) {
                    res.capturedImages["FRONT"]?.let { bitmap ->
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Analysis Base",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // --- BIOMETRIC SAMPLES ---
                SectionHeader("Visual Evidence")
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(res.capturedImages.toList()) { (key, bitmap) ->
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(RoundedCornerShape(32.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                        ) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = key,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            // Overlay label
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.4f))
                                    .padding(vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    key.uppercase(),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // --- AI DIAGNOSTICS ---
                SectionHeader("Aesthetic Insights")
                Column(
                    modifier = Modifier.padding(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    res.tips.forEach { tip ->
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            cornerRadius = 32
                        ) {
                            Row(verticalAlignment = Alignment.Top) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    null,
                                    tint = Color(0xFF64D2FF),
                                    modifier = Modifier.size(18.dp).padding(top = 2.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    tip,
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 14.sp,
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // --- METRIC BREAKDOWN ---
                SectionHeader("Detailed Vibe Metrics")
                Column(
                    modifier = Modifier.padding(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    res.detailedMetrics.forEach { metric ->
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            cornerRadius = 32
                        ) {
                            MetricRow(metric.name, metric.score)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
                
                LiquidButton(
                    text = "Export Biometric Protocol",
                    onClick = { shareReport(context, res) },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(64.dp))
            }
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        color = Color.White.copy(alpha = 0.4f),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(start = 4.dp)
    )
}

@Composable
fun MetricRow(label: String, score: Int) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("$score%", color = Color(0xFF64D2FF), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(14.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.1f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(score / 100f)
                    .fillMaxHeight()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF0A84FF), Color(0xFF64D2FF))
                        )
                    )
            )
        }
    }
}

@Composable
fun CircularRatingDisplay(score: Int) {
    val animatedScore = remember { Animatable(0f) }
    LaunchedEffect(score) {
        animatedScore.animateTo(score.toFloat(), animationSpec = tween(2000, easing = EaseOutQuart))
    }

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
        Box(
            modifier = Modifier
                .size(140.dp)
                .blur(40.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF0A84FF).copy(alpha = 0.2f), Color.Transparent)
                    )
                )
        )

        Canvas(modifier = Modifier.size(180.dp)) {
            val strokeWidth = 8.dp.toPx()
            drawCircle(
                color = Color.White.copy(alpha = 0.05f),
                style = Stroke(width = strokeWidth)
            )
            
            drawArc(
                color = Color(0xFF0A84FF),
                startAngle = -90f,
                sweepAngle = (animatedScore.value / 100f) * 360f,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
        
        val rating = (animatedScore.value / 10.0).roundToOneDecimal()
        
        Text(
            text = "$rating", 
            color = Color.White, 
            fontSize = 72.sp, 
            fontWeight = FontWeight.Bold,
            letterSpacing = (-2).sp
        )
    }
}

private fun Double.roundToOneDecimal(): Double {
    val factor = 10.0.pow(1.0)
    return (this * factor).roundToInt() / factor
}

private fun shareReport(context: Context, result: FaceAnalysisResult) {
    val rating = (result.overallScore / 10.0).roundToOneDecimal()
    val reportText = """
        ╔══════════════════════════════════════════╗
        ║       FACEHARMONY BIOMETRIC REPORT       ║
        ╚══════════════════════════════════════════╝
        
        DATE: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}
        PROTOCOL ID: FH-${(10000..99999).random()}
        
        [ SUMMARY ]
        Attractiveness Vibe: $rating/10
        Classification: ${when {
            result.overallScore > 90 -> "Elite Aesthetic Alignment"
            result.overallScore > 80 -> "High Structural Harmony"
            result.overallScore > 70 -> "Standard Aesthetic Proportions"
            else -> "Variational Biometric Data"
        }}
        
        [ METRIC BREAKDOWN ]
        ${result.detailedMetrics.joinToString("\n") { "• ${it.name.padEnd(20)}: ${it.score}%" }}
        
        [ AI DIAGNOSTIC INSIGHTS ]
        ${result.tips.joinToString("\n- ", prefix = "- ")}
        
        --------------------------------------------
        CONFIDENTIAL • ON-DEVICE NEURAL PROCESSING
        GENERATED BY FACEHARMONY AI
        --------------------------------------------
    """.trimIndent()

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Aesthetic Report: $rating/10")
        putExtra(Intent.EXTRA_TEXT, reportText)
    }
    context.startActivity(Intent.createChooser(intent, "Export Protocol"))
}
