package com.example.ratemelocalai.ui.screens

import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ratemelocalai.camera.FaceMeshAnalyzer
import com.example.ratemelocalai.camera.MediaPipeFaceAnalyzer
import com.example.ratemelocalai.domain.model.FaceAnalysisResult
import com.example.ratemelocalai.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImprovementTipsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val lastSavedResult by viewModel.lastResult.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var currentAnalysisResult by remember { mutableStateOf<FaceAnalysisResult?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            isProcessing = true
            errorMessage = null
            scope.launch {
                val analyzer = MediaPipeFaceAnalyzer(context)
                val result = withContext(Dispatchers.IO) {
                    analyzer.analyzeUri(it)
                }
                if (result != null) {
                    @Suppress("DEPRECATION")
                    val bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, it)
                    val analysisResult = FaceMeshAnalyzer.analyzeSingleImage(result, bitmap)
                    currentAnalysisResult = analysisResult
                    viewModel.setAnalysisResult(analysisResult)
                } else {
                    errorMessage = "No face detected in the selected photo."
                }
                isProcessing = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Glow-Up Guide", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = if (currentAnalysisResult != null) { { currentAnalysisResult = null } } else onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF050505)
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0A1A2F), Color(0xFF050505))
                    )
                )
        ) {
            when {
                isProcessing -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = Color(0xFF0A84FF))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Local AI Processing...", color = Color.White, fontWeight = FontWeight.Medium)
                        Text("Generating personalized tips", color = Color.Gray, fontSize = 12.sp)
                    }
                }
                currentAnalysisResult == null -> {
                    SelectionState(
                        lastResult = lastSavedResult,
                        onUseLast = { currentAnalysisResult = lastSavedResult },
                        onUpload = { photoLauncher.launch("image/*") },
                        error = errorMessage
                    )
                }
                else -> {
                    TipsContent(currentAnalysisResult!!)
                }
            }
        }
    }
}

@Composable
fun SelectionState(
    lastResult: FaceAnalysisResult?,
    onUseLast: () -> Unit,
    onUpload: () -> Unit,
    error: String?
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint = Color(0xFF0A84FF).copy(alpha = 0.6f)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            "Personalized Glow-Up",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold
        )
        Text(
            "How should the AI generate your protocol?",
            color = Color.Gray,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
        
        if (error != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(error, color = Color.Red, fontSize = 14.sp)
        }

        Spacer(modifier = Modifier.height(48.dp))
        
        if (lastResult != null) {
            Button(
                onClick = onUseLast,
                modifier = Modifier.fillMaxWidth().height(60.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f))
            ) {
                Icon(Icons.Default.History, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(12.dp))
                Text("Analyze Last Scan Data", fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        Button(
            onClick = onUpload,
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A84FF))
        ) {
            Icon(Icons.Default.Upload, contentDescription = null)
            Spacer(modifier = Modifier.width(12.dp))
            Text("Upload New Photo", fontWeight = FontWeight.Bold)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            "Analyses are 100% local and private.",
            color = Color.White.copy(alpha = 0.3f),
            fontSize = 12.sp
        )
    }
}

@Composable
fun TipsContent(result: FaceAnalysisResult) {
    val improvementTips = remember(result) { generateDynamicTips(result) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    "AI Protocol",
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    "Personalized for your biometric profile",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        items(improvementTips) { tip ->
            TipCard(tip)
        }
        
        item {
            Spacer(modifier = Modifier.height(40.dp))
            Text(
                "Note: These tips are generated by local AI based on facial landmarks. Re-scan weekly to track progress.",
                color = Color.Gray.copy(alpha = 0.5f),
                fontSize = 10.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun TipCard(tip: ImprovementTip) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(tip.color.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(tip.icon, contentDescription = null, tint = tip.color, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(tip.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(tip.description, color = Color.LightGray.copy(alpha = 0.8f), fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
    }
}

data class ImprovementTip(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val color: Color
)

fun generateDynamicTips(result: FaceAnalysisResult): List<ImprovementTip> {
    val tips = mutableListOf<ImprovementTip>()

    // 1. Jawline & Lower Face Fat
    val jawlinePhrases = listOf(
        "Optimize jawline definition: focus on masseter training and low body fat.",
        "To reveal your bone structure, prioritize 'Mewing' and reducing facial bloating.",
        "Your jawline can be sharpened. Try chewing mastic gum and maintaining proper tongue posture."
    )
    if (result.jawlineScore < 75) {
        tips.add(
            ImprovementTip(
                "Jawline & Face Fat",
                jawlinePhrases.random() + " Goal body fat: 10-14%.",
                Icons.Default.Star,
                Color(0xFF0A84FF)
            )
        )
    }

    // 2. Face Bloating / Water Retention
    val bloatingPhrases = listOf(
        "Detected facial water retention. Reduce salt and increase hydration (3L/day).",
        "Signs of bloating: use a cold Gua Sha in the morning to drain lymphatic fluid.",
        "Facial definition is masked by bloating. Try cold exposure (ice rolling) and daily dandelion tea."
    )
    if (result.cheekboneScore < 70) {
        tips.add(
            ImprovementTip(
                "De-Bloating Protocol",
                bloatingPhrases.random(),
                Icons.Default.Water,
                Color(0xFF64D2FF)
            )
        )
    }

    // 3. Skin Texture & Acne
    val skinPhrases = if (result.skinTextureScore < 80) {
        listOf(
            "Texture irregularities detected. Use Salicylic Acid for pores and Niacinamide for evenness.",
            "Improve skin clarity: prioritize double cleansing and daily SPF 50 application.",
            "Skin routine update: incorporate Retinol at night to boost cell turnover and smooth texture."
        )
    } else {
        listOf(
            "Excellent skin texture. Maintain with hydration and protective antioxidants like Vitamin C.",
            "Skin clarity is optimal. Don't skip moisturizer and keep your SPF routine consistent.",
            "Biometrics show healthy skin. Focus on maintenance: never sleep with product on."
        )
    }
    tips.add(
        ImprovementTip(
            "Skin Health",
            skinPhrases.random(),
            if (result.skinTextureScore < 80) Icons.Default.AutoFixHigh else Icons.Default.CheckCircle,
            Color(0xFF32D74B)
        )
    )

    // 4. Hair & Forehead Framing
    val hairPrefix = listOf("Hair Routine:", "Aesthetic Framing:", "Hair Optimization:")
    val hairTip = when {
        result.hairAnalysis.contains("thin", ignoreCase = true) -> 
            "Use Rosemary oil and ensure scalp health. Voluminous styles will balance your facial proportions."
        result.hairAnalysis.contains("receding", ignoreCase = true) -> 
            "Consider a textured fringe to mask recession. Keep sides short to emphasize verticality."
        else -> "Current style: ${result.hairAnalysis}. Balance your face shape with volume on top or textured sides."
    }
    tips.add(
        ImprovementTip(
            hairPrefix.random(),
            hairTip,
            Icons.Default.ContentCut,
            Color(0xFFAF52DE)
        )
    )

    // 5. Dark Circles & Eye Area
    val eyePhrases = if (result.eyeAreaScore < 75) {
        listOf(
            "Eye area shows fatigue. Use caffeine eye creams and ensure 8+ hours of deep sleep.",
            "Reduce dark circles by minimizing blue light exposure and using cold compresses.",
            "To brighten eyes, focus on hydration and supplementing with Vitamin K based creams."
        )
    } else {
        listOf(
            "Strong eye area support. Maintain with hydration and eye-specific UV protection.",
            "Eye biometrics are optimal. Continue focused sleep patterns to prevent future hollowing."
        )
    }
    tips.add(
        ImprovementTip(
            "Eye Revitalization",
            eyePhrases.random(),
            Icons.Default.RemoveRedEye,
            Color(0xFFFF9F0A)
        )
    )

    // 6. Bonus Tip (Always new)
    val bonusTips = listOf(
        ImprovementTip("Daily Posture", "Keep your chin up and shoulders back to improve jawline appearance instantly.", Icons.AutoMirrored.Filled.DirectionsRun, Color(0xFF8E8E93)),
        ImprovementTip("Hydration Hack", "Add electrolytes to your water to improve skin glow and reduce cellular bloating.", Icons.Default.LocalDrink, Color(0xFF5AC8FA)),
        ImprovementTip("Sleep Quality", "Sleep on your back with a silk pillowcase to prevent sleep wrinkles and asymmetry.", Icons.Default.Bedtime, Color(0xFF5856D6))
    )
    tips.add(bonusTips.random())

    return tips.shuffled()
}
