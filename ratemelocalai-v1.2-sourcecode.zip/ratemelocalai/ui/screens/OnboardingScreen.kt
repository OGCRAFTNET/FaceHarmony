package com.example.ratemelocalai.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ratemelocalai.ui.components.LiquidButton
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pages = remember {
        listOf(
            OnboardingPage(
                title = "Biometric Analysis",
                description = "Experience high-precision facial symmetry and proportion scanning using neural protocols.",
                icon = Icons.Default.Face,
                color = Color(0xFF0A84FF),
            ),
            OnboardingPage(
                title = "Dating Analyzer",
                description = "Optimize your digital presence. Get AI-driven insights on your profile's vibe and attraction.",
                icon = Icons.Default.Favorite,
                color = Color(0xFFFF2D55),
            ),
            OnboardingPage(
                title = "Best Photo AI",
                description = "Stop guessing. Let our statistical engine select your most impactful profile pictures.",
                icon = Icons.Default.AutoAwesome,
                color = Color(0xFFAF52DE),
            )
        )
    }

    val pagerState = rememberPagerState { pages.size }
    val scope = rememberCoroutineScope()

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        // --- DYNAMIC BACKGROUND ORBS ---
        val infiniteTransition = rememberInfiniteTransition(label = "bg_anim")
        val orbOffset by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 100f,
            animationSpec = infiniteRepeatable(
                animation = tween(8000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ), label = "orbOffset"
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .blur(100.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(400.dp)
                    .graphicsLayer {
                        translationX = (-100).dp.toPx() + orbOffset.dp.toPx()
                        translationY = (-100).dp.toPx()
                    }
                    .background(
                        Brush.radialGradient(
                            colors = listOf(pages[pagerState.currentPage].color.copy(alpha = 0.2f), Color.Transparent)
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(300.dp)
                    .align(Alignment.BottomEnd)
                    .graphicsLayer {
                        translationX = 100.dp.toPx() - orbOffset.dp.toPx()
                        translationY = 100.dp.toPx()
                    }
                    .background(
                        Brush.radialGradient(
                            colors = listOf(pages[pagerState.currentPage].color.copy(alpha = 0.15f), Color.Transparent)
                        )
                    )
            )
        }

        // --- PAGER CONTENT ---
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { pageIndex ->
            OnboardingContent(pages[pageIndex], pagerState.currentPage == pageIndex)
        }

        // --- FOOTER CONTROLS ---
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Page Indicator
            Row(
                modifier = Modifier.padding(bottom = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                repeat(pages.size) { i ->
                    val isActive = pagerState.currentPage == i
                    val width by animateDpAsState(if (isActive) 32.dp else 8.dp, label = "dot_width")
                    Box(
                        modifier = Modifier
                            .height(8.dp)
                            .width(width)
                            .clip(CircleShape)
                            .background(
                                if (isActive) pages[i].color else Color.White.copy(alpha = 0.2f)
                            )
                    )
                }
            }

            LiquidButton(
                text = if (pagerState.currentPage == (pages.size - 1)) "Initialize FaceHarmony" else "Next Protocol",
                onClick = {
                    if (pagerState.currentPage == pages.size - 1) onFinish()
                    else {
                        scope.launch {
                            pagerState.animateScrollToPage(pagerState.currentPage + 1)
                        }
                    }
                },
                modifier = Modifier.padding(horizontal = 48.dp).fillMaxWidth()
            )
            
            TextButton(
                onClick = onFinish,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("Skip Exploration", color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp, letterSpacing = 1.sp)
            }
        }
    }
}

data class OnboardingPage(
    val title: String, 
    val description: String, 
    val icon: ImageVector,
    val color: Color
)

@Composable
fun OnboardingContent(page: OnboardingPage, isVisible: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "content_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Feature Visual Representation
        Box(
            modifier = Modifier
                .size(280.dp)
                .graphicsLayer {
                    scaleX = pulseScale
                    scaleY = pulseScale
                },
            contentAlignment = Alignment.Center
        ) {
            // "Liquid Glass" Icon Container
            Box(
                modifier = Modifier
                    .fillMaxSize(0.7f)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.02f))
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = page.icon,
                    contentDescription = null,
                    tint = page.color,
                    modifier = Modifier.size(64.dp)
                )
            }
            
            // Decorative floating elements
            repeat(3) { i ->
                val floatAnim = rememberInfiniteTransition(label = "float_$i")
                val translateY by floatAnim.animateFloat(
                    initialValue = 0f,
                    targetValue = if (i % 2 == 0) 20f else -20f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(3000 + (i * 500), easing = EaseInOutSine),
                        repeatMode = RepeatMode.Reverse
                    ), label = "float_y"
                )
                
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .graphicsLayer {
                            translationX = (if (i == 0) (-100).dp else if (i == 1) 100.dp else 40.dp).toPx()
                            translationY = (if (i == 0) 60.dp else if (i == 1) (-60).dp else 120.dp).toPx() + translateY.dp.toPx()
                        }
                        .clip(CircleShape)
                        .background(page.color.copy(alpha = 0.6f))
                        .blur(4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        AnimatedVisibility(
            visible = isVisible,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = page.title.uppercase(),
                    color = Color.White,
                    style = MaterialTheme.typography.titleLarge,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = page.description,
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    lineHeight = 24.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    }
}
