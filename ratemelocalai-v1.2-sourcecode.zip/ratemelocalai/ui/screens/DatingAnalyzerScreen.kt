package com.example.ratemelocalai.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ratemelocalai.camera.MediaPipeFaceAnalyzer
import com.example.ratemelocalai.ui.components.GlassCard
import com.example.ratemelocalai.ui.components.LiquidBackground
import com.example.ratemelocalai.ui.components.LiquidButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun DatingAnalyzerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val analyzer = remember { MediaPipeFaceAnalyzer(context) }
    
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var analysisProgress by remember { mutableStateOf(0f) }
    var showResults by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    // Neural Result States
    var datingScore by remember { mutableStateOf(0.0) }
    var neuralInsights by remember { mutableStateOf(listOf<String>()) }
    var vibeMetrics by remember { mutableStateOf(listOf(0.7f, 0.5f, 0.8f, 0.6f, 0.9f)) }
    
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> 
            if (uri != null) {
                selectedImageUri = uri
                showResults = false
                analysisProgress = 0f
                isAnalyzing = false
                errorMessage = null
            }
        }
    )

    LaunchedEffect(isAnalyzing) {
        if (isAnalyzing) {
            errorMessage = null
            analysisProgress = 0f
            
            // 1. Initial Scan Phase
            while (analysisProgress < 0.4f) {
                delay(20)
                analysisProgress += 0.02f
            }

            // 2. Real Face Detection
            val faceFound = withContext(Dispatchers.IO) {
                selectedImageUri?.let { uri ->
                    val result = analyzer.analyzeUri(uri)
                    result != null && result.faceLandmarks().isNotEmpty()
                } ?: false
            }

            if (!faceFound) {
                errorMessage = "NO FACE DETECTED\nPlease use a clear photo of yourself."
                isAnalyzing = false
                return@LaunchedEffect
            }

            // 3. Final Analysis Phase
            while (analysisProgress < 1f) {
                delay(30)
                analysisProgress += 0.05f
            }
            
            // --- SIMULATE DYNAMIC NEURAL ANALYSIS ---
            datingScore = (65..96).random() / 10.0
            vibeMetrics = List(5) { Random.nextFloat().coerceIn(0.4f, 0.95f) }
            
            val pools = listOf(
                "High trustworthiness detected",
                "Optimal lighting for Hinge",
                "Warm expression increases matches",
                "Strong jawline definition",
                "Authentic smile detected",
                "Confident gaze composition",
                "Excellent color harmony",
                "Clear eye contact impact",
                "Approachable vibe index: High",
                "Professional depth perception"
            )
            neuralInsights = pools.shuffled().take(3)
            
            delay(400)
            isAnalyzing = false
            showResults = true
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LiquidBackground()
        
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // --- HEADER ---
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 56.dp, bottom = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Neural Dating Protocol",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = (-0.5).sp
                    )
                    Text("ALPHA STAGE", color = Color(0xFFFF2D55), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }

            // --- MAIN CONTENT ---
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                if (selectedImageUri == null) {
                    // Empty State: Liquid Image Picker
                    val infiniteTransition = rememberInfiniteTransition(label = "picker_pulse")
                    val pulseScale by infiniteTransition.animateFloat(
                        initialValue = 1f,
                        targetValue = 1.03f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(2500, easing = EaseInOutSine),
                            repeatMode = RepeatMode.Reverse
                        ), label = "pulseScale"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.85f)
                            .graphicsLayer {
                                scaleX = pulseScale
                                scaleY = pulseScale
                            }
                            .clip(RoundedCornerShape(40.dp))
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color(0xFFFF2D55).copy(alpha = 0.05f), Color.White.copy(alpha = 0.02f))
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(40.dp))
                            .clickable {
                                photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(100.dp)
                                    .blur(20.dp)
                                    .background(Color(0xFFFF2D55).copy(alpha = 0.15f), CircleShape)
                            )
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .offset(y = (-90).dp)
                                    .background(Color.White.copy(alpha = 0.05f), CircleShape)
                                    .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PhotoLibrary, null, tint = Color(0xFFFF2D55), modifier = Modifier.size(32.dp))
                            }
                            Text(
                                text = "TAP TO ANALYZE",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.offset(y = (-40).dp),
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "Optimized for Tinder/Hinge",
                                color = Color.White.copy(alpha = 0.3f),
                                fontSize = 12.sp,
                                modifier = Modifier.offset(y = (-35).dp)
                            )
                        }
                    }
                } else {
                    // Selection & Analysis State
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.85f)
                            .clip(RoundedCornerShape(40.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(40.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = selectedImageUri,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        
                        // Scanning Overlay
                        if (isAnalyzing) {
                            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .align(Alignment.TopCenter)
                                        .offset(y = (380 * analysisProgress).dp)
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color.Transparent, Color(0xFFFF2D55), Color.Transparent)
                                            )
                                        )
                                        .blur(10.dp)
                                )
                                Column(
                                    modifier = Modifier.align(Alignment.Center),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    CircularProgressIndicator(
                                        progress = { analysisProgress },
                                        color = Color(0xFFFF2D55),
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(48.dp),
                                        trackColor = Color.White.copy(alpha = 0.1f)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        "MAPPING VIBE MATRIX",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 2.sp
                                    )
                                }
                            }
                        }
                        
                        // Error Overlay
                        if (errorMessage != null) {
                            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.7f)), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                                    Icon(Icons.Default.Warning, null, tint = Color(0xFFFF453A), modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(errorMessage!!, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Button(
                                        onClick = { selectedImageUri = null; errorMessage = null },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f))
                                    ) {
                                        Text("TRY AGAIN", color = Color.White)
                                    }
                                }
                            }
                        }
                        
                        // Results Overlay
                        if (showResults) {
                            Box(
                                modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize().padding(16.dp),
                                    verticalArrangement = Arrangement.Bottom
                                ) {
                                    GlassCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        cornerRadius = 24,
                                        padding = 16.dp
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Column {
                                                    Text("DATING IMPACT", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    Text("${datingScore} / 10", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraLight)
                                                }
                                                Spacer(modifier = Modifier.weight(1f))
                                                VibeChart(vibeMetrics)
                                            }
                                            Spacer(modifier = Modifier.height(12.dp))
                                            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text("Neural Insights:", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            neuralInsights.forEach { insight ->
                                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                                    Icon(Icons.Default.CheckCircle, null, tint = Color(0xFFFF2D55), modifier = Modifier.size(12.dp))
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(insight, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- BOTTOM ACTIONS ---
            Spacer(modifier = Modifier.height(24.dp))
            
            Box(modifier = Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                if (selectedImageUri != null && !isAnalyzing && !showResults && errorMessage == null) {
                    LiquidButton(
                        text = "Analyze Neural Impact",
                        onClick = { isAnalyzing = true },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if ((showResults || (selectedImageUri != null && !isAnalyzing)) && errorMessage == null) {
                    TextButton(
                        onClick = { photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Try Another Photo", color = Color.White.copy(alpha = 0.4f), fontWeight = FontWeight.Medium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun VibeChart(metrics: List<Float>) {
    Canvas(modifier = Modifier.size(60.dp)) {
        val center = size.center
        val radius = size.minDimension / 2
        val path = Path()
        
        for (i in metrics.indices) {
            val angle = (i * 2 * PI / metrics.size) - (PI / 2)
            val x = center.x + (radius * metrics[i] * cos(angle)).toFloat()
            val y = center.y + (radius * metrics[i] * sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        
        drawPath(path, Color(0xFFFF2D55).copy(alpha = 0.3f))
        drawPath(path, Color(0xFFFF2D55), style = Stroke(width = 2.dp.toPx()))
    }
}
