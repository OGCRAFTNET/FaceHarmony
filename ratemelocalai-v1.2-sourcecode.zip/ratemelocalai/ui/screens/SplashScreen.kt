package com.example.ratemelocalai.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onNavigate: () -> Unit) {
    val appName = "FACEHARMONY"
    
    val alphaAnim = remember { Animatable(0f) }
    // Animate letter spacing for a cinematic "opening" effect
    val spacingAnim = remember { Animatable(4f) }
    val scaleAnim = remember { Animatable(1.05f) }

    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    val orbOffset by infiniteTransition.animateFloat(
        initialValue = -30f,
        targetValue = 30f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ), label = "orbOffset"
    )

    LaunchedEffect(Unit) {
        launch {
            // Smooth fade in
            alphaAnim.animateTo(1f, tween(2500, easing = EaseOutQuart))
            delay(1500)
            // Elegant fade out
            alphaAnim.animateTo(0f, tween(1500, easing = EaseInExpo))
        }
        
        launch {
            // Cinematic text expansion
            spacingAnim.animateTo(14f, tween(5000, easing = EaseOutQuart))
        }

        launch {
            // Subtle zoom out (inverse scale)
            scaleAnim.animateTo(1f, tween(5000, easing = EaseOutQuart))
        }
        
        delay(5500)
        onNavigate()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        // High-end "Harmony Orb" - Blurred cosmic background
        Box(
            modifier = Modifier
                .size(500.dp)
                .graphicsLayer {
                    translationY = orbOffset
                    alpha = alphaAnim.value * 0.35f
                    scaleX = 1.5f * (2f - scaleAnim.value)
                    scaleY = 1.2f * (2f - scaleAnim.value)
                }
                .background(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF4F46E5).copy(alpha = 0.4f), // Indigo
                            Color(0xFF7C3AED).copy(alpha = 0.15f), // Violet
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                alpha = alphaAnim.value
                scaleX = scaleAnim.value
                scaleY = scaleAnim.value
            }
        ) {
            Text(
                text = appName,
                color = Color.White,
                fontSize = 18.sp, // Slightly smaller to ensure it fits on one line
                fontWeight = FontWeight.ExtraLight,
                letterSpacing = spacingAnim.value.sp,
                modifier = Modifier.padding(start = spacingAnim.value.dp) // Offset for centering
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Minimalist animated separator
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(40.dp)
                    .graphicsLayer {
                        scaleY = alphaAnim.value
                    }
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.7f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }

        // Bottom cinematic tag
        Text(
            text = "NEURAL AESTHETICS",
            color = Color.White.copy(alpha = 0.2f * alphaAnim.value),
            fontSize = 10.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 8.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
        )
    }
}
