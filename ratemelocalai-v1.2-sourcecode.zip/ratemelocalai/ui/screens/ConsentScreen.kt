package com.example.ratemelocalai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ratemelocalai.ui.components.GlassCard
import com.example.ratemelocalai.ui.components.LiquidBackground
import com.example.ratemelocalai.ui.components.LiquidButton

@Composable
fun ConsentScreen(onAccepted: () -> Unit) {
    var ageConfirmed by remember { mutableStateOf(false) }
    var privacyAccepted by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        LiquidBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(64.dp))
            Text(
                text = "Privacy & Consent",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                letterSpacing = (-1).sp
            )
            Spacer(modifier = Modifier.height(32.dp))

            GlassCard {
                Column {
                    Text(
                        text = "Your Privacy is our Priority",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "FaceHarmony uses on-device AI to analyze your facial structure. No biometric data, images, or analysis results ever leave this device. We do not use cloud processing, and we do not track you.",
                        color = Color.LightGray.copy(alpha = 0.8f),
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            ConsentCheckbox(
                text = "I confirm that I am at least 13 years old (EU) / 16 years old (USA/Global).",
                checked = ageConfirmed,
                onCheckedChange = { ageConfirmed = it }
            )

            Spacer(modifier = Modifier.height(12.dp))

            ConsentCheckbox(
                text = "I agree to the local processing of my facial data for analysis purposes.",
                checked = privacyAccepted,
                onCheckedChange = { privacyAccepted = it }
            )

            Spacer(modifier = Modifier.weight(1f))
            Spacer(modifier = Modifier.height(48.dp))

            LiquidButton(
                text = "Continue",
                enabled = ageConfirmed && privacyAccepted,
                onClick = onAccepted,
                modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp)
            )
        }
    }
}

@Composable
fun ConsentCheckbox(text: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onCheckedChange(!checked) }
            .padding(vertical = 8.dp)
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = { onCheckedChange(it) },
            colors = CheckboxDefaults.colors(
                checkedColor = Color(0xFF0A84FF),
                uncheckedColor = Color.White.copy(alpha = 0.2f),
                checkmarkColor = Color.White
            )
        )
        Text(
            text = text,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 14.sp,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}
