package com.example.ratemelocalai.camera

import android.graphics.Bitmap
import com.example.ratemelocalai.domain.model.FaceAnalysisResult
import com.example.ratemelocalai.domain.model.FaceMetric
import com.example.ratemelocalai.domain.model.MetricStatus
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import kotlin.math.*

/**
 * Biometric Harmony Engine v1.3 - "Charisma & Vibe Focus"
 * Significantly reduced mathematical penalties, increased "Halo Effect" weights.
 * Optimized for perceived attractiveness rather than geometric perfection.
 */
object FaceMeshAnalyzer {

    data class FacePose(val yaw: Float, val pitch: Float, val roll: Float)

    fun analyzeSingleImage(result: FaceLandmarkerResult, bitmap: Bitmap): FaceAnalysisResult {
        return calculateFinalScore(
            mapOf("FRONT" to result),
            mapOf("FRONT" to bitmap)
        )
    }

    fun calculateFinalScore(
        capturedResults: Map<String, FaceLandmarkerResult?>,
        capturedBitmaps: Map<String, Bitmap>
    ): FaceAnalysisResult {
        val frontResult = capturedResults["FRONT"] ?: return emptyResult()
        if (frontResult.faceLandmarks().isEmpty()) return emptyResult()
        val frontLandmarks = frontResult.faceLandmarks()[0]

        // --- ATTRACTIVENESS & VIBE MODULES ---
        
        val harmonyScore = calculateRealisticProportions(frontLandmarks)
        val eyeAppealScore = calculateOrbitalHarmonization(frontLandmarks)
        val gazeScore = calculateCanthalTilt(frontLandmarks)
        val compactnessScore = calculateMidfaceRatio(frontLandmarks)
        val jawlineSharpness = calculateJawlineArchitecture(frontLandmarks)
        val structureScore = calculateGonialAngle(frontLandmarks)
        val dominanceScore = calculateFWHR(frontLandmarks)
        val balanceScore = calculatePreciseSymmetry(frontLandmarks)
        val browVibeScore = calculateBrowEyeSpacing(frontLandmarks)
        val lipAppealScore = calculateLipAesthetics(frontLandmarks)
        val hairVibeScore = calculateHairAesthetics(frontLandmarks)
        val skinVibeScore = (92..99).random() 

        // --- REFINED ATTRACTIVENESS REGRESSION (V1.3 CHARISMA FOCUS) ---
        // We now use a "Halo" multiplier that rewards high scores in key areas
        // Pure math (Symmetry/Proportions) now has very low weight.
        val baseBeauty = (
            eyeAppealScore * 0.22f +     // Eyes are the core of attractiveness
            gazeScore * 0.18f +          // "Hunter eyes" / Positive tilt impact
            hairVibeScore * 0.15f +      // Styling and framing
            lipAppealScore * 0.12f +     // Feature fullness
            jawlineSharpness * 0.10f +   // Definition
            compactnessScore * 0.08f +   // Midface density
            dominanceScore * 0.05f +     // Presence
            harmonyScore * 0.04f +       // Reduced math weight
            browVibeScore * 0.03f +      // Support
            balanceScore * 0.02f +       // Asymmetry is natural, low penalty
            skinVibeScore * 0.01f
        )

        // "Charisma Boost" - If your best features are great, the overall score climbs faster
        val bestFeatureBonus = listOf(eyeAppealScore, gazeScore, hairVibeScore).maxOrNull()?.let { (it - 70).coerceAtLeast(0) / 10f } ?: 0f
        
        // Final stabilization: Base + Bonus + Random "Vibe" factor (Shifted upwards)
        val overall = (baseBeauty + bestFeatureBonus + (12..18).random() / 10.0).toInt().coerceIn(62, 99)
        val estimatedAge = runDeepAgeInference(frontLandmarks)

        val metrics = listOf(
            FaceMetric("Charisma Score", (baseBeauty + 8).toInt().coerceIn(0, 100), "Overall aesthetic impact and visual appeal.", getStatus(eyeAppealScore + 5)),
            FaceMetric("Eye Appeal", eyeAppealScore, "Ocular brightness and magnetic gaze.", getStatus(eyeAppealScore)),
            FaceMetric("Aesthetic Gaze", gazeScore, "Canthal tilt and eye angle attractiveness.", getStatus(gazeScore)),
            FaceMetric("Hair Framing", hairVibeScore, "Style impact and facial framing quality.", getStatus(hairVibeScore)),
            FaceMetric("Lip Aesthetics", lipAppealScore, "Shape and aesthetic volume of the lips.", getStatus(lipAppealScore)),
            FaceMetric("Jawline Definition", jawlineSharpness, "Definition and clarity of the lower face.", getStatus(jawlineSharpness)),
            FaceMetric("Facial Harmony", harmonyScore, "General balance of facial features.", getStatus(harmonyScore))
        )

        return FaceAnalysisResult(
            overallScore = overall,
            symmetryScore = balanceScore,
            jawlineScore = jawlineSharpness,
            proportionsScore = harmonyScore,
            eyeAreaScore = eyeAppealScore,
            cheekboneScore = calculateZygomaticProminence(frontLandmarks),
            skinTextureScore = skinVibeScore,
            estimatedAge = estimatedAge,
            hairAnalysis = getHairAnalysisText(hairVibeScore),
            tips = generateClinicalReport(metrics, estimatedAge, overall),
            detailedMetrics = metrics,
            capturedImages = capturedBitmaps
        )
    }

    private fun runDeepAgeInference(landmarks: List<NormalizedLandmark>): Int {
        val h = abs(landmarks[10].y() - landmarks[152].y()).toDouble().coerceAtLeast(0.1)
        val w = calculateDist(landmarks[234], landmarks[454]).toDouble().coerceAtLeast(0.1)
        
        val philtrum = abs(landmarks[2].y() - landmarks[0].y()).toDouble()
        val pRatio = philtrum / h
        
        val eyeHeight = abs(landmarks[159].y() - landmarks[145].y()).toDouble()
        val eRatio = eyeHeight / w
        
        val lowerFace = abs(landmarks[2].y() - landmarks[152].y()).toDouble()
        val lfRatio = lowerFace / h

        var age = 16.0 

        if (pRatio > 0.06) { age += (pRatio - 0.06) * 140.0 } else { age -= (0.06 - pRatio) * 10.0 }
        if (lfRatio > 0.39) { age += (lfRatio - 0.39) * 70.0 }
        if (eRatio < 0.044) { age += (0.044 - eRatio) * 80.0 } else { age -= (eRatio - 0.044) * 15.0 }
        
        val midFaceHeight = abs(landmarks[9].y() - landmarks[2].y()).toDouble()
        val mfRatio = midFaceHeight / h
        if (mfRatio > 0.34) age += (mfRatio - 0.34) * 30.0

        if (pRatio < 0.058 && lfRatio < 0.40 && eRatio > 0.045) {
            age = 15.0 + (age - 15.0).coerceIn(0.0, 6.0)
        }

        return age.toInt().coerceIn(15, 78)
    }

    private fun calculateHairAesthetics(landmarks: List<NormalizedLandmark>): Int {
        val fHead = abs(landmarks[10].y() - landmarks[9].y())
        val h = abs(landmarks[10].y() - landmarks[152].y())
        val ratio = fHead / h.coerceAtLeast(0.01f)
        val base = (100 - (abs(ratio - 0.31f) * 150)).toInt() // Reduced penalty
        return (base + (5..12).random()).coerceIn(60, 99)
    }

    private fun getHairAnalysisText(score: Int) = when {
        score > 90 -> "Elite Aesthetic Flow"
        score > 80 -> "Strong Styling & Framing"
        score > 65 -> "Good Volume & Shape"
        else -> "Style Optimization Potential"
    }

    private fun calculateGonialAngle(landmarks: List<NormalizedLandmark>): Int {
        val jaw = landmarks[172]; val chin = landmarks[152]
        return (calculateDist(jaw, chin) * 480 + 35).toInt().coerceIn(60, 98)
    }

    private fun calculateCanthalTilt(landmarks: List<NormalizedLandmark>): Int {
        val inner = landmarks[133]; val outer = landmarks[33]
        val tilt = atan2((inner.y() - outer.y()).toDouble(), (outer.x() - inner.x()).toDouble()) * (180.0 / PI)
        return (88 + tilt * 3.5).toInt().coerceIn(55, 99) // More generous base
    }

    private fun calculateBrowEyeSpacing(landmarks: List<NormalizedLandmark>): Int {
        val brow = landmarks[105]; val lid = landmarks[159]
        val dist = abs(brow.y() - lid.y())
        return (100 - (dist * 400)).toInt().coerceIn(60, 98) // Reduced penalty
    }

    private fun calculateFWHR(landmarks: List<NormalizedLandmark>): Int {
        val w = calculateDist(landmarks[234], landmarks[454])
        val h = abs(landmarks[9].y() - landmarks[13].y())
        val ratio = w / h.coerceAtLeast(0.01f)
        return (100 - (abs(ratio - 1.88f) * 35)).toInt().coerceIn(58, 98) // Reduced penalty
    }

    private fun calculateMidfaceRatio(landmarks: List<NormalizedLandmark>): Int {
        val eyeY = (landmarks[33].y() + landmarks[263].y()) / 2f
        val midH = abs(landmarks[2].y() - eyeY)
        val w = calculateDist(landmarks[234], landmarks[454])
        val ratio = w / midH.coerceAtLeast(0.01f)
        return (100 - (abs(ratio - 1.02f) * 60)).toInt().coerceIn(60, 98) // Reduced penalty
    }

    private fun calculateLipAesthetics(landmarks: List<NormalizedLandmark>): Int {
        val upper = abs(landmarks[0].y() - landmarks[13].y())
        val lower = abs(landmarks[14].y() - landmarks[17].y())
        val total = upper + lower
        val eyeD = calculateDist(landmarks[33], landmarks[263])
        return (total / eyeD.coerceAtLeast(0.01f) * 600 + 10).toInt().coerceIn(60, 99)
    }

    private fun calculateRealisticProportions(landmarks: List<NormalizedLandmark>): Int {
        val fHead = abs(landmarks[10].y() - landmarks[9].y())
        val mid = abs(landmarks[9].y() - landmarks[2].y())
        val low = abs(landmarks[2].y() - landmarks[152].y())
        val total = (fHead + mid + low).coerceAtLeast(0.01f)
        val dev = abs(fHead/total - 0.33f) + abs(mid/total - 0.33f) + abs(low/total - 0.33f)
        return (100 - (dev * 180)).toInt().coerceIn(65, 99) // Very low math penalty
    }

    private fun calculatePreciseSymmetry(landmarks: List<NormalizedLandmark>): Int {
        val midX = landmarks[1].x()
        val pairs = listOf(33 to 263, 133 to 362, 61 to 291, 234 to 454)
        var dev = 0f
        pairs.forEach { (l, r) -> dev += abs(abs(landmarks[l].x() - midX) - abs(landmarks[r].x() - midX)) }
        return (100 - (dev * 150)).toInt().coerceIn(70, 99) // Asymmetry is natural
    }

    private fun calculateOrbitalHarmonization(landmarks: List<NormalizedLandmark>): Int {
        val eyeW = calculateDist(landmarks[33], landmarks[263])
        val eyeH = calculateDist(landmarks[159], landmarks[145])
        val ratio = eyeW / eyeH.coerceAtLeast(0.01f)
        return (100 - (abs(ratio - 2.45f) * 8)).toInt().coerceIn(65, 99)
    }

    private fun calculateJawlineArchitecture(landmarks: List<NormalizedLandmark>): Int {
        val chin = landmarks[152]; val jaw = landmarks[172]
        return (calculateDist(chin, jaw) * 500 + 40).toInt().coerceIn(65, 98)
    }

    private fun calculateZygomaticProminence(landmarks: List<NormalizedLandmark>): Int {
        val cheek = landmarks[234]; val eye = landmarks[133]
        return (abs(cheek.y() - eye.y()) * 520 + 45).toInt().coerceIn(65, 98)
    }

    private fun generateClinicalReport(metrics: List<FaceMetric>, age: Int, overall: Int): List<String> {
        val rating = (overall / 10.0).roundTo(1)
        return listOf(
            "Aesthetic Rating: $rating/10",
            "Biometric Age: $age",
            "Charisma Index: Elite Level",
            "Top Feature: ${metrics.maxByOrNull { it.score }?.name}"
        )
    }

    private fun Double.roundTo(decimals: Int): Double {
        val factor = 10.0.pow(decimals)
        return (this * factor).roundToInt() / factor
    }

    private fun calculateDist(p1: NormalizedLandmark, p2: NormalizedLandmark): Float {
        return sqrt((p1.x() - p2.x()).pow(2) + (p1.y() - p2.y()).pow(2))
    }

    fun detectPose(result: FaceLandmarkerResult?): FacePose? {
        if (result == null || result.faceLandmarks().isEmpty()) return null
        val l = result.faceLandmarks()[0]
        val eyeMidX = (l[33].x() + l[263].x()) / 2f
        val yaw = (l[1].x() - eyeMidX) * 450f
        return FacePose(yaw, 0f, 0f)
    }

    private fun emptyResult() = FaceAnalysisResult(0,0,0,0,0,0,0)
    private fun getStatus(s: Int) = when { s > 90 -> MetricStatus.EXCELLENT; s > 80 -> MetricStatus.GOOD; s > 65 -> MetricStatus.AVERAGE; else -> MetricStatus.IMPROVABLE }
}
