package com.example.ratemelocalai.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ratemelocalai.domain.model.FaceAnalysisResult
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

class DataRepository(private val context: Context) {
    private val gson = Gson()
    private val LAST_RESULT_KEY = stringPreferencesKey("last_result")
    private val HISTORY_KEY = stringPreferencesKey("history")
    private val ONBOARDING_KEY = stringPreferencesKey("onboarding_completed")

    val lastResultFlow: Flow<FaceAnalysisResult?> = context.dataStore.data.map { preferences ->
        preferences[LAST_RESULT_KEY]?.let { gson.fromJson(it, FaceAnalysisResult::class.java) }
    }

    val historyFlow: Flow<List<FaceAnalysisResult>> = context.dataStore.data.map { preferences ->
        val json = preferences[HISTORY_KEY] ?: "[]"
        val type = object : TypeToken<List<FaceAnalysisResult>>() {}.type
        gson.fromJson(json, type)
    }

    val onboardingCompletedFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[stringPreferencesKey("onboarding_completed")]?.toBoolean() ?: false
    }

    suspend fun saveLastResult(result: FaceAnalysisResult) {
        context.dataStore.edit { preferences ->
            preferences[LAST_RESULT_KEY] = gson.toJson(result)
        }
    }

    suspend fun saveHistory(history: List<FaceAnalysisResult>) {
        context.dataStore.edit { preferences ->
            preferences[HISTORY_KEY] = gson.toJson(history)
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[stringPreferencesKey("onboarding_completed")] = completed.toString()
        }
    }

    suspend fun clearAllData() {
        context.dataStore.edit { it.clear() }
    }
}
